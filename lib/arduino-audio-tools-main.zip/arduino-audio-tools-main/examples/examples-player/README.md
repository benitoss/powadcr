# AudioPlayer Examples

see [the Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/The-Audio-Player-Class)
You can find some more examples in the AudioKit