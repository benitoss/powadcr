# Desktop

You can use the AudioTools on the desktop w/o Arduino: Just compile your sketch with the following steps

- mkdir build
- cd build
- cmake ..
- make

Further information can be found in the [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki)!