# Streaming Radio Player

We just play a streamed radio station which provides the audio as aac and output the result via I2S to an external DAC

