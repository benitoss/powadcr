
We provide our own HTTP protocal implementation which includes a simple webserver.
Initially this was part of the core functionality, but has been changed to __optional functionality__
in order to optimize the sketch size.