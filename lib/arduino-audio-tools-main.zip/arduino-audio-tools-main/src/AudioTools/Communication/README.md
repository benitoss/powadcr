
Different optional classes to send and receive audio over the wire or air