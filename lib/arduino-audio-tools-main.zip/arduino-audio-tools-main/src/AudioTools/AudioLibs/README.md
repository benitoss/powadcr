
Integration to different optonal external audio libraries